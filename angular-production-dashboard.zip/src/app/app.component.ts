import { Component } from '@angular/core';
import { ChartData, ChartOptions } from 'chart.js';

/**
 * The root component of the production dashboard. It contains
 * all of the data used to power the dashboard widgets, charts and
 * tables. For simplicity all values are hard‑coded, but in a real
 * application these would likely come from services making HTTP
 * requests to a backend API.
 */
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // Top metric values
  ordersInProgress = 128;
  completedOrders = 87;
  efficiency = 92;

  // Line chart configuration for orders overview
  lineChartData: ChartData<'line'> = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'],
    datasets: [
      {
        data: [5, 7, 6, 8, 7, 9, 8, 10, 9],
        label: 'Orders',
        fill: true,
        tension: 0.3,
        backgroundColor: 'rgba(93, 173, 226, 0.2)',
        borderColor: '#5dade2',
        pointBackgroundColor: '#5dade2'
      }
    ]
  };

  lineChartOptions: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      }
    },
    scales: {
      x: {
        ticks: {
          color: '#777777'
        },
        grid: {
          color: '#f0f0f0'
        }
      },
      y: {
        ticks: {
          color: '#777777'
        },
        grid: {
          color: '#f0f0f0'
        },
        suggestedMin: 0,
        suggestedMax: 12
      }
    }
  };

  // Pie chart configuration for order status distribution
  pieChartData: ChartData<'pie', number[], string> = {
    labels: ['In Progress', 'Completed', 'Pending'],
    datasets: [
      {
        data: [34, 34, 34],
        backgroundColor: ['#5dade2', '#52be80', '#f5b041'],
        hoverBackgroundColor: ['#5499c7', '#45b06e', '#edbb5f']
      }
    ]
  };

  pieChartOptions: ChartOptions<'pie'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right' as const
      }
    }
  };

  // Recent orders for the table
  recentOrders = [
    { orderId: '435-4835', customer: 'John Toome', status: 'In Progress', dueDate: 'Jun, 22' },
    { orderId: '433-4832', customer: 'Joe Fornant', status: 'Completed', dueDate: 'Jul, 19' },
    { orderId: '433-4839', customer: 'Pets Pattile', status: 'Pending', dueDate: 'Jun, 15' },
    { orderId: '439-4443', customer: 'Tom Putlips', status: 'In Progress', dueDate: 'Jun, 13' },
    { orderId: '433-4897', customer: 'Rane Upon', status: 'Completed', dueDate: 'Jun, 14' },
    { orderId: '433-4466', customer: 'Samuar Willer', status: 'Pending', dueDate: 'Jun, 13' }
  ];

  // Production metrics values displayed on the right panel
  productionMetrics = {
    averageCycleTime: '8.2 hrs',
    detectRate: '1.5%',
    unitsProduced: '12,385',
    downtime: '8.7 hrs'
  };
}