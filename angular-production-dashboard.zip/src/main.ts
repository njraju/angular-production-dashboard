import { bootstrapApplication } from '@angular/platform-browser';
import { importProvidersFrom } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgChartsModule } from 'ng2-charts';
import { AppComponent } from './app/app.component';

/*
 * The entry point of the Angular application. It bootstraps the root
 * component using the standalone API introduced in Angular 14+. We
 * import BrowserModule and NgChartsModule via `importProvidersFrom` to
 * ensure the necessary providers are registered. This approach keeps
 * the project lightweight and avoids the need for a separate
 * AppModule file.
 */
bootstrapApplication(AppComponent, {
  providers: [
    importProvidersFrom(BrowserModule, NgChartsModule)
  ]
}).catch((err) => console.error(err));